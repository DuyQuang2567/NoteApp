package com.thanggun99.noteapp.view.activity;

public class ProgressDialog {
    public ProgressDialog(MainActivity mainActivity) {
    }
}
